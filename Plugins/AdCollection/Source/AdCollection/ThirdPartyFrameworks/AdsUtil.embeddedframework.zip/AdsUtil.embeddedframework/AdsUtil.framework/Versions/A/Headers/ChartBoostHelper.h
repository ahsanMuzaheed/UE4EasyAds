//
//  ChartBoost.h
//  AdsUtil
//
//  Created by Xufei Wu on 2017/6/28.
//  Copyright © 2017年 Xufei Wu. All rights reserved.
//

#ifndef ChartBoostHelper_h
#define ChartBoostHelper_h


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ChartBoostHelper : NSObject

+ (ChartBoostHelper*) GetDelegate;
- (void) InitSDK:(NSString*) AppID AppSignature:(NSString*)AppSignature callback:(void(*)(int amount)) callback;
-(void) ShowInterstitialAds;
-(void) IsInterstitalReady:(NSMutableDictionary*)result;
-(void) Play:(UIViewController*) viewController;
-(void) IsPlayable:(NSMutableDictionary*)result;

@end

#endif /* ChartBoost_h */
